package ude.edu.uy.ejemplourlconnectionrestclient;

public interface SimpleUpdatableActivity {
    public void update(RestDataDto... results);
}
